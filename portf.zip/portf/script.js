console.log("Welcome to Varshitha N's Portfolio!");
